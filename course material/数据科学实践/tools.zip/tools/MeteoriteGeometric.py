class MeteoriteGeometricAugment:
    """
    几何增强：模拟不同拍摄角度和位置
    关键：气印结构必须保持拓扑不变
    """
    def __init__(self, img_size=384):
        self.img_size = img_size
        
    def __call__(self, img):
        # img: PIL Image
        w, h = img.size
        
        # 1. 随机裁剪（模拟不同构图）
        # 使用scale保证陨石主体在画面中
        scale = random.uniform(0.8, 1.0)
        new_h, new_w = int(h * scale), int(w * scale)
        
        if scale < 1.0:
            top = random.randint(0, h - new_h)
            left = random.randint(0, w - new_w)
            img = TF.crop(img, top, left, new_h, new_w)
            
        # 2. 水平翻转（陨石无左右偏好，合理）
        if random.random() < 0.5:
            img = TF.hflip(img)
            
        # 3. 垂直翻转：⚠️ 需要谨慎！
        # 陨石有重力方向（熔壳通常在上），但数据集可能有各种摆放
        # 建议根据验证集表现决定是否启用
        # if random.random() < 0.1:
        #     img = TF.vflip(img)
        
        # 4. 旋转（模拟倾斜拍摄）
        # 限制角度：气印在极端旋转下可能难以识别
        angle = random.uniform(-15, 15)  # 保守范围
        img = TF.rotate(img, angle, fill=128)  # 灰色填充
        
        # 5. 轻微透视（模拟相机不平行于表面）
        # 使用affine简化实现
        if random.random() < 0.3:
            shear = random.uniform(-5, 5)
            img = TF.affine(img, angle=0, translate=(0,0), 
                          scale=1.0, shear=shear, fill=128)
        
        # 最终resize
        img = TF.resize(img, (self.img_size, self.img_size))
        
        return img
