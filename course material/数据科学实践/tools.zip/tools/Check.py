def visualize_augmentations(image_path, n_samples=8):
    """
    可视化增强效果，检查是否破坏关键特征
    """
    import matplotlib.pyplot as plt
    
    img = Image.open(image_path).convert('RGB')
    aug = MeteoriteAugmentation(img_size=384, mode='train')
    
    fig, axes = plt.subplots(2, n_samples//2, figsize=(16, 8))
    
    for i, ax in enumerate(axes.flat):
        augmented = aug(img)
        # tensor [C,H,W] -> numpy [H,W,C]
        vis = augmented.permute(1, 2, 0).numpy()
        # 反归一化
        vis = vis * np.array([0.229, 0.224, 0.225]) + np.array([0.485, 0.456, 0.406])
        vis = np.clip(vis, 0, 1)
        
        ax.imshow(vis)
        ax.set_title(f'Sample {i+1}')
        ax.axis('off')
        
    plt.tight_layout()
    plt.savefig('augmentation_check.png', dpi=150)
    plt.close()
    
    # 检查清单：
    # 1. 熔壳颜色是否保持深色调？
    # 2. 气印结构是否可辨识？
    # 3. 是否有不自然的伪影？
    # 4. 旋转后陨石方向是否合理？


def check_augmentation_consistency(model, dataloader, n_batches=10):
    """
    验证：同一图像多次增强后预测一致性
    一致性高 = 增强合理；一致性低 = 可能过度增强
    """
    model.eval()
    variances = []
    
    with torch.no_grad():
        for batch_idx, (imgs, labels) in enumerate(dataloader):
            if batch_idx >= n_batches:
                break
                
            # 对同一张图增强10次
            img = imgs[0:1]  # 取第一张
            preds = []
            
            aug = MeteoriteAugmentation(mode='train')
            for _ in range(10):
                # 需要原始PIL
                pil_img = TF.to_pil_image(img[0])
                aug_img = aug(pil_img).unsqueeze(0)
                pred = model(aug_img).sigmoid().item()
                preds.append(pred)
                
            variance = np.var(preds)
            variances.append(variance)
            
            print(f"Image {batch_idx}: pred_mean={np.mean(preds):.3f}, "
                  f"var={variance:.4f}")
            
    print(f"\n平均预测方差: {np.mean(variances):.4f}")
    print("参考: <0.01=很稳定, 0.01-0.05=合理, >0.1=可能过度增强")
