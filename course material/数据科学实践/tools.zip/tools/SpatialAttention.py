#空间注意力优化（针对陨石特征）：聚焦判别区域
#陨石的熔壳边缘和气印区域是判别关键，但只占图像小部分
class SpatialAttentionGate(nn.Module):
    """在CNN→Transformer之间加入空间门控"""
    def __init__(self, dim):
        self.attn = nn.Sequential(
            nn.Conv2d(dim, dim//8, 1),
            nn.ReLU(),
            nn.Conv2d(dim//8, 1, 1),
            nn.Sigmoid()
        )
        
    def forward(self, x):
        # x: [B, C, H, W] from CNN
        attn_map = self.attn(x)  # [B, 1, H, W]
        
        # 增强高响应区域（熔壳/气印）
        x = x * attn_map
        
        # 同时保留全局信息（残差）
        return x + x * (1 - attn_map)  # 软选择
