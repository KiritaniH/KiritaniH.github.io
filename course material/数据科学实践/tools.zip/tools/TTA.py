class MeteoriteTTA:
    """
    测试时增强：多视角预测聚合
    对F1优化尤其重要（减少假阴性）
    """
    def __init__(self, n_augments=5):
        self.n_augments = n_augments
        
    def __call__(self, model, img):
        """
        img: [C, H, W] tensor
        """
        preds = []
        
        # 原始图像
        preds.append(model(img.unsqueeze(0)).sigmoid())
        
        # 水平翻转
        preds.append(model(TF.hflip(img).unsqueeze(0)).sigmoid())
        
        # 轻微旋转（模拟拍摄角度差异）
        for angle in [-5, 5]:
            rot_img = TF.rotate(img, angle, fill=128)
            preds.append(model(rot_img.unsqueeze(0)).sigmoid())
            
        # 轻微缩放（模拟距离差异）
        scaled = TF.resize(TF.center_crop(img, int(img.size(1)*0.9)), img.size(1))
        preds.append(model(scaled.unsqueeze(0)).sigmoid())
        
        # 聚合：平均（也可用加权，如原始图像权重更高）
        final_pred = torch.stack(preds).mean()
        
        # 对陨石类（1）更保守：如果任一增强预测为高，则倾向正类
        # 这提升召回率，对F1有利
        max_pred = torch.stack(preds).max()
        final_pred = 0.7 * final_pred + 0.3 * max_pred  # 偏向召回
        
        return final_pred
