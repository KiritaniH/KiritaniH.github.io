import albumentations as A
from albumentations.pytorch import ToTensorV2

class MeteoriteAugmentation:
    """
    完整的陨石数据增强Pipeline
    分为：训练模式 / 验证模式 / 强增强（半监督用）
    """
    
    def __init__(self, img_size=384, mode='train'):
        self.mode = mode
        self.img_size = img_size
        
        # 基础预处理（所有模式共用）
        self.base_transform = A.Compose([
            A.Resize(img_size, img_size),
            A.Normalize(
                mean=[0.485, 0.456, 0.406],  # ImageNet预训练
                std=[0.229, 0.224, 0.225]
            ),
            ToTensorV2()
        ])
        
        if mode == 'train':
            self.transform = A.Compose([
                # 几何增强
                A.RandomResizedCrop(
                    height=img_size, 
                    width=img_size,
                    scale=(0.8, 1.0),  # 保留大部分陨石主体
                    ratio=(0.9, 1.1),  # 接近正方形（陨石通常居中）
                    p=1.0
                ),
                A.HorizontalFlip(p=0.5),
                A.ShiftScaleRotate(
                    shift_limit=0.05,
                    scale_limit=0.1,
                    rotate_limit=15,  # 保守旋转
                    border_mode=0,    # 常数填充
                    value=128,        # 灰色填充
                    p=0.5
                ),
                
                # 像素增强
                A.RandomBrightnessContrast(
                    brightness_limit=0.2,
                    contrast_limit=0.2,
                    p=0.5
                ),
                A.RandomGamma(gamma_limit=(80, 120), p=0.3),
                
                # 颜色增强（保守）
                A.HueSaturationValue(
                    hue_shift_limit=5,    # 几乎不动色相
                    sat_shift_limit=15,   # 轻微饱和度
                    val_shift_limit=15,   # 明度
                    p=0.3
                ),
                
                # 纹理增强
                A.Sharpen(alpha=(0.2, 0.5), lightness=(0.5, 1.0), p=0.3),
                A.OneOf([
                    A.GaussNoise(var_limit=(5.0, 20.0), p=1.0),
                    A.ISONoise(intensity=(0.1, 0.3), p=1.0)
                ], p=0.2),
                
                # 模糊（模拟失焦，保守）
                A.OneOf([
                    A.MotionBlur(blur_limit=3, p=1.0),
                    A.MedianBlur(blur_limit=3, p=1.0)
                ], p=0.1),
                
                # 遮挡增强（模拟其他物体部分遮挡）
                A.CoarseDropout(
                    max_holes=3,
                    max_height=int(img_size*0.1),
                    max_width=int(img_size*0.1),
                    fill_value=128,
                    p=0.2
                ),
                
                # 归一化
                A.Normalize(
                    mean=[0.485, 0.456, 0.406],
                    std=[0.229, 0.224, 0.225]
                ),
                ToTensorV2()
            ])
            
        elif mode == 'strong':  # 用于半监督/伪标签
            self.transform = A.Compose([
                # 更强的增强用于无标签数据
                A.RandomResizedCrop(img_size, img_size, scale=(0.6, 1.0)),
                A.HorizontalFlip(p=0.5),
                A.VerticalFlip(p=0.1),  # 偶尔尝试
                A.ShiftScaleRotate(shift_limit=0.1, scale_limit=0.2, 
                                 rotate_limit=30, p=0.7),
                A.RandomBrightnessContrast(brightness_limit=0.3, contrast_limit=0.3),
                A.HueSaturationValue(hue_shift_limit=10, sat_shift_limit=30, p=0.5),
                A.Sharpen(p=0.5),
                A.GaussNoise(var_limit=(10, 50), p=0.3),
                A.RandomShadow(p=0.2),  # 模拟阴影
                
                A.Normalize(mean=[0.485, 0.456, 0.406], 
                          std=[0.229, 0.224, 0.225]),
                ToTensorV2()
            ])
            
        else:  # val/test
            self.transform = self.base_transform
            
    def __call__(self, image):
        # 支持PIL Image或numpy array
        if isinstance(image, Image.Image):
            image = np.array(image)
            
        augmented = self.transform(image=image)
        return augmented['image']
