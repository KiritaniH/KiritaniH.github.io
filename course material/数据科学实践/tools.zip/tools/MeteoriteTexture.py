class MeteoriteTextureAugment:
    """
    纹理级增强：增强表面细节感知
    针对气印（凹坑）和熔壳（光滑/粗糙过渡）
    """
    def __init__(self, p=0.3):
        self.p = p
        
    def __call__(self, img):
        if random.random() > self.p:
            return img
            
        # 转为PIL处理
        if isinstance(img, torch.Tensor):
            img = TF.to_pil_image(img)
            
        # 1. 锐化（增强气印边缘）
        if random.random() < 0.4:
            factor = random.uniform(1.5, 3.0)
            enhancer = ImageEnhance.Sharpness(img)
            img = enhancer.enhance(factor)
            
        # 2. 轻微浮雕效果（模拟侧光，突出凹凸）
        # 对气印识别可能有帮助
        if random.random() < 0.2:
            img = img.filter(ImageFilter.EMBOSS)
            # 与原图混合，避免过度失真
            img = Image.blend(img, img, alpha=0.7)
            
        # 3. 高频噪声（模拟相机噪声，增强鲁棒性）
        if random.random() < 0.2:
            img_np = np.array(img).astype(np.float32)
            noise = np.random.normal(0, 5, img_np.shape)
            img_np = np.clip(img_np + noise, 0, 255).astype(np.uint8)
            img = Image.fromarray(img_np)
            
        return img
