#标准Mixup/CutMix对陨石可能不适用——把两块岩石混合会产生"非物理"图像。需要同类混合或区域级混合。
class MeteoriteMixAugment:
    """
    改进版混合增强：保持语义一致性
    """
    def __init__(self, alpha=0.4, mix_prob=0.5):
        self.alpha = alpha
        self.mix_prob = mix_prob
        
    def __call__(self, batch_imgs, batch_labels):
        """
        batch_imgs: [B, C, H, W]
        batch_labels: [B]  0=非陨石, 1=陨石
        """
        if random.random() > self.mix_prob:
            return batch_imgs, batch_labels
            
        B = batch_imgs.size(0)
        
        # 策略1：同类Mixup（陨石+陨石，非陨石+非陨石）
        # 避免生成"半陨石"这种物理不存在的样本
        for c in [0, 1]:
            mask = (batch_labels == c)
            idx = torch.where(mask)[0]
            
            if len(idx) < 2:
                continue
                
            # 同类内随机配对
            perm = torch.randperm(len(idx))
            for i in range(0, len(idx)-1, 2):
                i1, i2 = idx[perm[i]], idx[perm[i+1]]
                
                lam = np.random.beta(self.alpha, self.alpha)
                batch_imgs[i1] = lam * batch_imgs[i1] + (1-lam) * batch_imgs[i2]
                # 标签保持为c（因为同类混合）
                
        return batch_imgs, batch_labels


class MeteoriteCutMix:
    """
    区域级CutMix：模拟"部分遮挡"或"多岩石场景"
    对陨石识别有意义：野外照片中可能有其他岩石部分遮挡
    """
    def __init__(self, alpha=1.0, prob=0.5):
        self.alpha = alpha
        self.prob = prob
        
    def __call__(self, imgs, labels):
        if random.random() > self.prob:
            return imgs, labels
            
        B, C, H, W = imgs.shape
        perm = torch.randperm(B)
        
        for i in range(B):
            # 只进行同类CutMix，或跨类但调整标签
            if labels[i] == labels[perm[i]]:
                # 同类：标签不变
                lam = np.random.beta(self.alpha, self.alpha)
                
                # 随机矩形区域
                cut_w = int(W * np.sqrt(1 - lam))
                cut_h = int(H * np.sqrt(1 - lam))
                cx = random.randint(0, W)
                cy = random.randint(0, H)
                
                x1 = np.clip(cx - cut_w // 2, 0, W)
                y1 = np.clip(cy - cut_h // 2, 0, H)
                x2 = np.clip(cx + cut_w // 2, 0, W)
                y2 = np.clip(cy + cut_h // 2, 0, H)
                
                imgs[i, :, y1:y2, x1:x2] = imgs[perm[i], :, y1:y2, x1:x2]
                # 标签 = 原标签（同类替换）
                
            else:
                # 跨类：模拟"背景岩石+前景陨石"
                # 仅当陨石(1)被非陨石(0)遮挡时，标签变为0（被遮挡）
                # 或陨石覆盖非陨石，标签变为1
                # 这里简化处理：跳过跨类，避免标签模糊
                pass
                
        return imgs, labels
