import torch
import torchvision.transforms as T
import torchvision.transforms.functional as TF
import random
import numpy as np
from PIL import Image, ImageFilter, ImageEnhance

class MeteoritePixelAugment:
    """
    像素级增强：模拟不同拍摄条件
    保守策略——不改变陨石本质特征
    """
    def __init__(self, p=0.5):
        self.p = p
        
    def __call__(self, img):
        # img: PIL Image or Tensor [C,H,W]
        if random.random() > self.p:
            return img
            
        ops = []
        
        # 1. 光照变化（陨石在不同光线下拍摄）
        # 熔壳反光特性对光照敏感
        if random.random() < 0.3:
            factor = random.uniform(0.7, 1.3)
            ops.append(lambda x: TF.adjust_brightness(x, factor))
            
        # 2. 对比度（增强气印与基质的差异）
        if random.random() < 0.3:
            factor = random.uniform(0.8, 1.4)
            ops.append(lambda x: TF.adjust_contrast(x, factor))
            
        # 3. 轻微饱和度变化（熔壳颜色稳定性）
        if random.random() < 0.2:
            factor = random.uniform(0.9, 1.1)  # 很保守
            ops.append(lambda x: TF.adjust_saturation(x, factor))
            
        # 4. 伽马校正（模拟不同相机响应）
        if random.random() < 0.2:
            gamma = random.uniform(0.8, 1.2)
            ops.append(lambda x: TF.adjust_gamma(x, gamma))
            
        # 随机顺序应用
        random.shuffle(ops)
        for op in ops:
            img = op(img)
            
        return img
