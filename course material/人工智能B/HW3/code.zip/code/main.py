# gridworld.py
# ------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
#
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


import random
import sys
import util
import optparse

class MarkovDecisionProcess:

    def getStates(self):
        """
        Return a list of all states in the MDP.
        Not generally possible for large MDPs.
        """
        pass

    def getStartState(self):
        """
        Return the start state of the MDP.
        """
        pass

    def getPossibleActions(self, state):
        """
        Return list of possible actions from 'state'.
        """
        pass

    def getTransitionStatesAndProbs(self, state, action):
        """
        Returns list of (nextState, prob) pairs
        representing the states reachable
        from 'state' by taking 'action' along
        with their transition probabilities.

        Note that in Q-Learning and reinforcment
        learning in general, we do not know these
        probabilities nor do we directly model them.
        """
        pass

    def getReward(self, state, action, nextState):
        """
        Get the reward for the state, action, nextState transition.

        Not available in reinforcement learning.
        """
        pass

    def isTerminal(self, state):
        """
        Returns true if the current state is a terminal state.  By convention,
        a terminal state has zero future rewards.  Sometimes the terminal state(s)
        may have no possible actions.  It is also common to think of the terminal
        state as having a self-loop action 'pass' with zero reward; the formulations
        are equivalent.
        """
        pass

class Gridworld(MarkovDecisionProcess):
    """
      Gridworld
    """
    def __init__(self, grid):
        # layout
        if type(grid) == type([]): grid = makeGrid(grid)
        self.grid = grid

        # parameters
        self.livingReward = 0.0
        self.noise = 0.2

    def setLivingReward(self, reward):
        """
        The (negative) reward for exiting "normal" states.

        Note that in the R+N text, this reward is on entering
        a state and therefore is not clearly part of the state's
        future rewards.
        """
        self.livingReward = reward

    def setNoise(self, noise):
        """
        The probability of moving in an unintended direction.
        """
        self.noise = noise

    def getPossibleActions(self, state):
        """
        Returns list of valid actions for 'state'.

        Note that you can request moves into walls and
        that "exit" states transition to the terminal
        state under the special action "done".
        """
        if state == self.grid.terminalState:
            return ()
        x,y = state
        if type(self.grid[x][y]) == int:
            return ('exit',)
        return ('north','west','south','east')

    def getStates(self):
        """
        Return list of all states.
        """
        # The true terminal state.
        states = [self.grid.terminalState]
        for x in range(self.grid.width):
            for y in range(self.grid.height):
                if self.grid[x][y] != '#':
                    state = (x,y)
                    states.append(state)
        return states

    def getReward(self, state, action, nextState):
        """
        Get reward for state, action, nextState transition.

        Note that the reward depends only on the state being
        departed (as in the R+N book examples, which more or
        less use this convention).
        """
        if state == self.grid.terminalState:
            return 0.0
        x, y = state
        cell = self.grid[x][y]
        if type(cell) == int or type(cell) == float:
            return cell
        return self.livingReward

    def getStartState(self):
        for x in range(self.grid.width):
            for y in range(self.grid.height):
                if self.grid[x][y] == 'S':
                    return (x, y)
        raise 'Grid has no start state'

    def isTerminal(self, state):
        """
        Only the TERMINAL_STATE state is *actually* a terminal state.
        The other "exit" states are technically non-terminals with
        a single action "exit" which leads to the true terminal state.
        This convention is to make the grids line up with the examples
        in the R+N textbook.
        """
        return state == self.grid.terminalState


    def getTransitionStatesAndProbs(self, state, action):
        """
        Returns list of (nextState, prob) pairs
        representing the states reachable
        from 'state' by taking 'action' along
        with their transition probabilities.
        """

        if action not in self.getPossibleActions(state):
            raise "Illegal action!"

        if self.isTerminal(state):
            return []

        x, y = state

        if type(self.grid[x][y]) == int or type(self.grid[x][y]) == float:
            termState = self.grid.terminalState
            return [(termState, 1.0)]

        successors = []

        northState = (self.__isAllowed(y+1,x) and (x,y+1)) or state
        westState = (self.__isAllowed(y,x-1) and (x-1,y)) or state
        southState = (self.__isAllowed(y-1,x) and (x,y-1)) or state
        eastState = (self.__isAllowed(y,x+1) and (x+1,y)) or state

        if action == 'north' or action == 'south':
            if action == 'north':
                successors.append((northState,1-self.noise))
            else:
                successors.append((southState,1-self.noise))

            massLeft = self.noise
            successors.append((westState,massLeft/2.0))
            successors.append((eastState,massLeft/2.0))

        if action == 'west' or action == 'east':
            if action == 'west':
                successors.append((westState,1-self.noise))
            else:
                successors.append((eastState,1-self.noise))

            massLeft = self.noise
            successors.append((northState,massLeft/2.0))
            successors.append((southState,massLeft/2.0))

        successors = self.__aggregate(successors)

        return successors

    def __aggregate(self, statesAndProbs):
        counter = util.Counter()
        for state, prob in statesAndProbs:
            counter[state] += prob
        newStatesAndProbs = []
        for state, prob in list(counter.items()):
            newStatesAndProbs.append((state, prob))
        return newStatesAndProbs

    def __isAllowed(self, y, x):
        if y < 0 or y >= self.grid.height: return False
        if x < 0 or x >= self.grid.width: return False
        return self.grid[x][y] != '#'

class Environment:

    def getCurrentState(self):
        """
        Returns the current state of enviornment
        """
        pass

    def getPossibleActions(self, state):
        """
          Returns possible actions the agent
          can take in the given state. Can
          return the empty list if we are in
          a terminal state.
        """
        pass

    def doAction(self, action):
        """
          Performs the given action in the current
          environment state and updates the enviornment.

          Returns a (reward, nextState) pair
        """
        pass

    def reset(self):
        """
          Resets the current state to the start state
        """
        pass

    def isTerminal(self):
        """
          Has the enviornment entered a terminal
          state? This means there are no successors
        """
        state = self.getCurrentState()
        actions = self.getPossibleActions(state)
        return len(actions) == 0

class GridworldEnvironment(Environment):

    def __init__(self, gridWorld):
        self.gridWorld = gridWorld
        self.reset()

    def getCurrentState(self):
        return self.state

    def getPossibleActions(self, state):
        return self.gridWorld.getPossibleActions(state)

    def doAction(self, action):
        state = self.getCurrentState()
        (nextState, reward) = self.getRandomNextState(state, action)
        self.state = nextState
        return (nextState, reward)

    def getRandomNextState(self, state, action, randObj=None):
        rand = -1.0
        if randObj is None:
            rand = random.random()
        else:
            rand = randObj.random()
        sum = 0.0
        successors = self.gridWorld.getTransitionStatesAndProbs(state, action)
        for nextState, prob in successors:
            sum += prob
            if sum > 1.0:
                raise 'Total transition probability more than one; sample failure.'
            if rand < sum:
                reward = self.gridWorld.getReward(state, action, nextState)
                return (nextState, reward)
        raise 'Total transition probability less than one; sample failure.'

    def reset(self):
        self.state = self.gridWorld.getStartState()

class Grid:
    """
    A 2-dimensional array of immutables backed by a list of lists.  Data is accessed
    via grid[x][y] where (x,y) are cartesian coordinates with x horizontal,
    y vertical and the origin (0,0) in the bottom left corner.

    The __str__ method constructs an output that is oriented appropriately.
    """
    def __init__(self, width, height, initialValue=' '):
        self.width = width
        self.height = height
        self.data = [[initialValue for y in range(height)] for x in range(width)]
        self.terminalState = 'TERMINAL_STATE'

    def __getitem__(self, i):
        return self.data[i]

    def __setitem__(self, key, item):
        self.data[key] = item

    def __eq__(self, other):
        if other == None: return False
        return self.data == other.data

    def __hash__(self):
        return hash(self.data)

    def copy(self):
        g = Grid(self.width, self.height)
        g.data = [x[:] for x in self.data]
        return g

    def deepCopy(self):
        return self.copy()

    def shallowCopy(self):
        g = Grid(self.width, self.height)
        g.data = self.data
        return g

    def _getLegacyText(self):
        t = [[self.data[x][y] for x in range(self.width)] for y in range(self.height)]
        t.reverse()
        return t

    def __str__(self):
        return str(self._getLegacyText())

def makeGrid(gridString):
    width, height = len(gridString[0]), len(gridString)
    grid = Grid(width, height)
    for ybar, line in enumerate(gridString):
        y = height - ybar - 1
        for x, el in enumerate(line):
            grid[x][y] = el
    return grid

def getDiscountGrid():
    grid = [[' ',' ',' ',' ',' '],
            [' ','#',' ',' ',' '],
            [' ','#', 1,'#', 10],
            ['S',' ',' ',' ',' '],
            [-10,-10, -10, -10, -10]]
    return Gridworld(grid)

def getBridgeGrid():
    grid = [[ '#',-100, -100, -100, -100, -100, '#'],
            [   1, 'S',  ' ',  ' ',  ' ',  ' ',  10],
            [ '#',-100, -100, -100, -100, -100, '#']]
    return Gridworld(grid)

def getBookGrid():
    grid = [[' ',' ',' ',+1],
            [' ','#',' ',-1],
            ['S',' ',' ',' ']]
    return Gridworld(grid)

def printString(x): print(x)

def runEpisode(agent, environment, discount, decision, display, message, pause, episode):
    returns = 0
    totalDiscount = 1.0
    environment.reset()
    if 'startEpisode' in dir(agent): agent.startEpisode()
    message("BEGINNING EPISODE: "+str(episode)+"\n")
    while True:

        # DISPLAY CURRENT STATE
        state = environment.getCurrentState()
        display(state)
        pause()

        # END IF IN A TERMINAL STATE
        actions = environment.getPossibleActions(state)
        if len(actions) == 0:
            message("EPISODE "+str(episode)+" COMPLETE: RETURN WAS "+str(returns)+"\n")
            return returns

        # GET ACTION (USUALLY FROM AGENT)
        action = decision(state)
        if action == None:
            Exception('Error: Agent returned None action')
            
        # EXECUTE ACTION
        nextState, reward = environment.doAction(action)
        message("Started in state: "+str(state)+
                "\nTook action: "+str(action)+
                "\nEnded in state: "+str(nextState)+
                "\nGot reward: "+str(reward)+"\n")
        # UPDATE LEARNER
        if 'observeTransition' in dir(agent):
            agent.observeTransition(state, action, nextState, reward)

        returns += reward * totalDiscount
        totalDiscount *= discount

    if 'stopEpisode' in dir(agent):
        agent.stopEpisode()

def parseOptions():
    optParser = optparse.OptionParser()
    optParser.add_option('-d', '--discount',action='store',
                         type='float',dest='discount',default=0.95,
                         help='Discount on future (default %default)')
    optParser.add_option('-e', '--epsilon',action='store',
                         type='float',dest='epsilon',default=0.1,
                         metavar="E", help='Epsilon for convergence checking')
    optParser.add_option('-i', '--iterations',action='store',
                         type='int',dest='iters',default=10,
                         metavar="K", help='Number of rounds of value iteration (default %default)')
    optParser.add_option('-k', '--episodes',action='store',
                         type='int',dest='episodes',default=1,
                         metavar="K", help='Number of epsiodes of the MDP to run (default %default)')
    optParser.add_option('-g', '--grid',action='store',
                         metavar="G", type='string',dest='grid',default="BookGrid",
                         help='Grid to use (case sensitive; options are BookGrid, BridgeGrid, default %default)' )
    optParser.add_option('-a', '--agent',action='store', metavar="A",
                         type='string',dest='agent',default="random",
                         help='Agent type')
    optParser.add_option('--alpha', dest='alpha', type='float', default=0.2,
                  help='learning rate for TD/Q-learning (default 0.2)')
    optParser.add_option('--depth',action='store',
                         type='int',dest='depth',default=4,
                         metavar="D", help='Depth for expectimax (default %default)')

    opts, _ = optParser.parse_args()

    return opts


if __name__ == '__main__':

    opts = parseOptions()

    ###########################
    # GET THE GRIDWORLD
    ###########################

    mdpFunction = eval("get"+opts.grid)
    mdp = mdpFunction()
    env = GridworldEnvironment(mdp)

    ###########################
    # GET THE DISPLAY ADAPTER
    ###########################

    import graphicsGridworldDisplay
    display = graphicsGridworldDisplay.GraphicsGridworldDisplay(mdp, 150, 1.0)
    display.start()

    ###########################
    # GET THE AGENT
    ###########################

    from valueIterationAgent import ValueIterationAgent
    from expectimaxAgent import ExpectimaxAgent
    from policyIterationAgent import PolicyIterationAgent
    # ===============================
    # TD-Learning Agent integration
    # ===============================
    from TDlearningAgent import TDLearningAgent
    # ===============================
    # Q-Learning Agent integration
    # ===============================
    from QLearningAgent import QLearningAgent


    # ---------------- choose your agent ----------------
    a = None
    if opts.agent == 'value':
        a = ValueIterationAgent(mdp, opts.discount, opts.epsilon, opts.iters)
    elif opts.agent == 'expectimax':
        a = ExpectimaxAgent(mdp, opts.depth)
    elif opts.agent == 'policy':
        a = PolicyIterationAgent(mdp, opts.discount, opts.epsilon, opts.iters)
    elif opts.agent == 'td':
        print("Using TD-Learning Agent")
        a = TDLearningAgent(
            mdp,
            discount=opts.discount,
            alpha=opts.alpha
        )
    elif opts.agent == 'q':
        print("Using Q-Learning Agent")
        a = QLearningAgent(
            mdp,
            discount=opts.discount,
            alpha=opts.alpha,
            epsilon=opts.epsilon
        )
    else:
        raise Exception('Unknown agent type: ' + opts.agent)

    ###########################
    # RUN EPISODES
    ###########################

    try:
        if opts.agent in ('value', 'policy'):
            display.displayValues(a, message = "FINAL VALUES")
            display.pause()
            display.displayQValues(a, message = "FINAL Q VALUES")
            display.pause()
    except KeyboardInterrupt:
        sys.exit(0)

    # FIGURE OUT WHAT TO DISPLAY EACH TIME STEP (IF ANYTHING)
    displayCallback = lambda x: None

    if opts.agent in ('value', 'expectimax', 'policy'):
        displayCallback = lambda state: display.displayValues(a, state, "CURRENT VALUES")

    messageCallback = lambda x: printString(x)

    # FIGURE OUT WHETHER TO WAIT FOR A KEY PRESS AFTER EACH TIME STEP
    pauseCallback = lambda : None

    # FIGURE OUT WHETHER THE USER WANTS MANUAL CONTROL (FOR DEBUGGING AND DEMOS)
    decisionCallback = a.getAction



    # --- STATE VALUE TRACKING SETUP ---
    import matplotlib.pyplot as plt
    import numpy as np
    import time

    # Choose states to track (adjust to your coordinate system)
    # --- BookGrid tracked states (0-indexed) ---
    tracked_states = [(3, 2), (2, 2), (0, 0), (2, 0), (3, 0)]

    # Container for per-episode traces
    values_trace = {s: [] for s in tracked_states}

    def state_value(agent, s):
        """
        Return current state value for plotting.
        Prefer agent.getValue(s). If not available, safely fallback to max_a Q(s,a)
        with guards to avoid invalid coordinates or terminal token.
        """
        # 1) Prefer the agent's own getValue (TD has it; Q-learning should also provide it)
        if hasattr(agent, "getValue"):
            try:
                return agent.getValue(s)
            except Exception:
                pass  # fall through to guarded Q-based computation

        # 2) Guard: ensure s is a valid non-terminal state before calling mdp methods
        try:
            # terminal token (often a special object) must be excluded
            if (s not in mdp.getStates()) or mdp.isTerminal(s):
                return 0.0
            actions = mdp.getPossibleActions(s)
            if not actions:
                return 0.0
        except Exception:
            # If anything goes wrong (e.g., indexing), return a safe default
            return 0.0

        # 3) Safe fallback: compute V(s) = max_a Q(s,a)
        if hasattr(agent, "getQValue"):
            return max(agent.getQValue(s, a) for a in actions)
        return 0.0


    # --- RUN EPISODES ---
    ep_returns = []              # collect every return
    total_return = 0.0

    if opts.episodes > 0:
        print("\nRUNNING", opts.episodes, "EPISODES\n")

    for episode in range(1, opts.episodes + 1):
        ret = runEpisode(
            a, env, opts.discount,
            decisionCallback, displayCallback, messageCallback, pauseCallback, episode
        )
        ep_returns.append(ret)   # save every return
        total_return += ret

        # Record V(s) or max_a Q(s,a) for tracked states after this episode
        for s in tracked_states:
            values_trace[s].append(state_value(a, s))


    if ep_returns:
        print("\nAVERAGE RETURNS FROM START STATE:", total_return / len(ep_returns), "\n")
    else:
        print("\n[WARN] No episodes were run or returns not collected.\n")



    # ===== collect per-episode returns and plot learning curve =====

    # try:
    #     ep_returns = getattr(a, "episode_returns", None)
    # except Exception:
    #     ep_returns = None

    # save as CSV（for plotting）
    import csv, time
    ts = int(time.time())
    # csv_path = f"episode_returns_{ts}.csv"
    # with open(csv_path, "w", newline="") as f:
    #     w = csv.writer(f)
    #     w.writerow(["episode", "return"])
    #     for i, r in enumerate(ep_returns, 1):
    #         w.writerow([i, r])
    # print("[Saved]", csv_path)

    # drwa learning curve
    import matplotlib.pyplot as plt
    import numpy as np

    def moving_average(x, k=50):
        if k <= 1 or k > len(x):
            return np.array(x, dtype=float)
        c = np.cumsum(np.insert(x, 0, 0.0))
        return (c[k:] - c[:-k]) / k

    if len(ep_returns) >= 1:
        plt.figure()
        plt.plot(range(1, len(ep_returns)+1), ep_returns, label="Return per episode")
        # smothing windows（size：10/20/50）
        ma = moving_average(ep_returns, k=min(1000, max(2, len(ep_returns)//20)))
        plt.plot(range(len(ma)), ma, label="Moving average")
        plt.xlabel("Episode")
        plt.ylabel("Return (discounted)")
        plt.title("Learning Curve")
        plt.legend()
        png_path = f"learning_curve_{ts}.png"
        plt.savefig(png_path, dpi=150, bbox_inches="tight")
        # plt.show()  # if need a window
        print("[Saved]", png_path)
    else:
        print("No episode returns to plot. Make sure you append returns in the loop:")
        print("  ret = runEpisode(...); ep_returns.append(ret)")



    # --- PLOT STATE VALUE CONVERGENCE CURVES ---
    xs = np.arange(1, len(ep_returns) + 1)

    plt.figure()
    for s, ys in values_trace.items():
        # Guard to align x/y lengths (should be equal to episodes)
        plt.plot(xs[:len(ys)], ys, label=str(s))

    plt.xlabel("Number of episodes")
    plt.ylabel("Utility estimates  V(s)")  # For Q-learning, this is max_a Q(s,a)
    plt.title("Convergence of utilities for selected states (TD/Q)")
    plt.legend()
    out = f"utilities_trace_{int(time.time())}.png"
    plt.savefig(out, dpi=150, bbox_inches="tight")
    plt.close()
    print("[Saved]", out)


    print()
    display.displayValues(a)
    display.displayQValues(a)

    # block so the window stays open
    try:
        import graphicsUtils
        # Try one of these depending on what your graphicsUtils exposes:
        if hasattr(graphicsUtils, "wait_for_keys"):
            graphicsUtils.wait_for_keys()
        elif hasattr(graphicsUtils, "sleep"):
            graphicsUtils.sleep(1e6)
        else:
            input("Press ENTER to close the graphics window...")
    except Exception:
        input("Press ENTER to close the graphics window...")





